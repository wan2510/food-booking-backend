package com.app.food_booking_backend.constant;

public interface GlobalConstant {
}
