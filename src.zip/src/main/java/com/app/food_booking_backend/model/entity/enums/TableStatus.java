package com.app.food_booking_backend.model.entity.enums;

public enum TableStatus {
    AVAILABLE, OCCUPIED, RESERVED
}
