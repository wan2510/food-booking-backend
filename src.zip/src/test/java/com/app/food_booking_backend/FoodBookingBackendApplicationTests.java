package com.app.food_booking_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodBookingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
